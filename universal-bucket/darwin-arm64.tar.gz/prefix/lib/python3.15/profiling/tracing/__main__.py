"""Run the tracing profiler from the command line."""

from profiling.tracing import main

if __name__ == '__main__':
    main()
